## CMMS - Computerized maintenance management system

### CMMS Module Specifiation
### A. Equipment Management
   - Equipment / Asset
     - Uniq ID
     - Procedures
     - Hierarchy (Parent-Child)
     - Priority (What fix first ?)
     - Auxiliary Equipment
     - Cost (Calc by WO. Useful for Machine Replacement Analysis - MRA)
     - Links ( attach CAD, Shematics, Pneumatics, Scanned Doc, Img)
       - able to call in WOs or POs
     - Safety And Compliance
     - Warranty (able to show under warranty in WO)
     - Condition Monitoring
     - Reports
       - Cost
       - Failure, Count
       - Hirarchy
       - Warranty
       - Availability (Time available during a specified period)
       - Special Tools
       - Meter Reading
       - Location
   - Labor
   - WO
   - Inventory
   - Purchasing
   - Equipment History via WOs
   - Spare Parts (Recommended Info)
   - Run Time (use to trigger PM)
   - Safety Procedures
   - PM Schedules

#### Tables
- asset : main properties
- asset_type : type of asset
- asset_contact : contact of asset incase there is any ploblem
- asset_part : middle table of asset-inventory
- asset_depreciation : depreciation of asset
- asset_comment : kind of log
- asset_downtime : downtime log
- asset_meter : meter of asset use for pm trigger
- asset_service_log : service log

-----

### B. Preventive Maintenance (PM)
   - Intro
     - Perfromed regularly based on Calendar Time or Run Time (see Equipment Management)
     - Generate WO
   - Procedures
     - Task Details, Parts, Tools, Labor
   - Priority
   - Frequency
     - Calendar Time (weekly, monthly, ..) or Run Time (Miles, Hours, ..), Seasonal (summer, snow, ..)
   - Parts
     - Parts required including qty
   - Labor
     - Enter Craft Categories (Mechanic, Electrician, ..) and estimated hours
   - Outside Contrator
     - Able to contract to outside Vendor
   - Links as (Equipment Module)
   - Functions
     - Generate WOs on its frequency setting
     - Route-based PM, a list of activities or inspections on a number of different equipment
       that are done by craft ppl
   - Reports
     - list by period of time
     - labor including money spent
     - material spent
     - labor projection (Use to forcast labor by specificed period)
     - material projetion (Use to forcast material by specificed period)

### Tables
- pm
- pm_step
- pm_dependency
- pm_comment
- pm_tool
- pm_audit
- pm_part
- pm_meter
- pm_safety
- pm_downtime
- pm_season
- pm_labor
- pm_asset
- pm_doc

----

### C. Labor
   - Properties
     - Hourly Wage Rate, Accomodate Overtime
     - Categories
     - Shift / Vocation / Sick
     - Craft Code
   - Links - as Equipment Management
   - Reports
     - Overtime
     - Vacation
     - WOs, Hours by account number / employee ID / Calendar Period / Equipment
     - Productivity ( estimated and actual hours )

---

### D. Work Order System (WO)
   - Intro
     - stores all preventive and corrective plan
     - emergency and scheduled
     - able to request by another department
   - Priority ( use for scheduled aid )
   - Status ( Approval, Wait for Material .. )
   - Category ( PM, Emergency, Repair, Project ) * should be user defined
   - Failure Code ( Should be user defined )
   - Action Code
   - Labor
     - able to enter multiple crafts ppl
   - Material ( Upon completion or as material is withdrawn )
   - Material Cost
   - Labor Cost
     - Based on Time Spent by each craft
   - Outside Cost and Total estimated cost
   - Total Actual Cost
   - WO completion
     - can be closed by individual or bath that matchs key
   - Downtime
     - able to track both planned and unplaned downtime
     - Planned means equipment is scheduled to be available for maintenance work
     - Unplanned means equipment goes down unexpectedly
   - Report
     - WO parts shortage
     - Active WO
     - Overdue WO
     - WO Material requirement
     - WO Labor requirement
     - WO detail
     - Downtime summary
     - WO by account
     - Activities
     - Performance ( % complete in time )
     - Cost Summary
     - Labor Summary
     - Material Summary
     - Equipment History
     - Cost Variance
   - Planning / Scheduling
   - Backlog
   - Priority System and Backlog
     - RIF - Relative Importance Factor = Priority X Equipment Criticality
     - Plan and schedule WOs based on RIF

### Tables
- workorder
- wo_step
- wo_labor
- wo_sched_labor
- wo_part
- wo_comment
- wo_semaphor
- wo_attachment
- wo_meter
- wo_tool
- wo_status_log
- wo_safety
- wo_doc
- wo_generation
- wo_planned_downtime
- wo_planned_part
- wo_planned_labor
- wo_planned_tool

---

### E. Vendor
   - Report
     - Able to print Label
     - Contact Report
     - Cost Variance

---

### F. Inventory
   - User defined reorder points
   - Able to create POs to restock
   - Many model to calc ROP(reorder point) and EOQ(economic order quantity)
   - Item trasactions
   - Description
   - Subsitiute

### Tables
- inventory : main properties
- in_tran : inventory transaction
- in_vendor : middle table of inventory-vendor
- in_comment : inventory comment
- in_type : type of inventory
- in_doc : link to document
- in_reserved : middle table of workorder-inventory
- in_audit : middle table of users-inventory
- in_location : location
- in_trans_worksheet
- in_stock : location and qty

---

### Install and Basic Needs

```bash
   Install rails guide here http://rubyonrails.org/download/
   second clone my project,
   config database connection at config/database.yml
   then go into the root project directory and run
   rake db:migrate # to initialize database schema
   ruby db:seed # to initialize data
   then run the server by
   rails s
   for flexible of used and modification. learn Rails http://rubyonrails.org/documentation/
```

### Demo site

```
http://cmms.heroku.com/
for admin role
user: admin@email.com
pass: 123123
for manager role
user: manager@email.com
pass: 123123
for staff role
user: staff@email.com
pass: 123123
```

----

### Remark

- This project is not ready to use and no more development activities
- This project could assist you only database design part. Please see the model folder for the idea
- You can use whatever web framework you familiar

---

### Android version

This repository now includes an Android app in the `android/` directory. It is a native Android WebView shell for the Rails CMMS application.

The Rails app must still run on a server. During development, start Rails with:

```bash
rails s -b 0.0.0.0 -p 3000
```

Then open the `android/` folder in Android Studio and run the app. The default Android emulator URL is:

```text
http://10.0.2.2:3000/
```

For a physical Android device, tap **Server** inside the app and use your computer/server IP address, for example `http://192.168.1.50:3000/`.

See `android/README.md` for full Android setup and production notes.

## Build Android APK on GitHub

This repository includes a GitHub Actions workflow at `.github/workflows/build-android-apk.yml`.

To generate the APK:

1. Push the project to GitHub.
2. Open the repository on GitHub.
3. Go to **Actions**.
4. Select **Build Android APK**.
5. Click **Run workflow**.
6. When the workflow finishes, download the `CMMS-debug-apk` artifact.

The debug APK will be built from the Android project in `android/` and uploaded from:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Before sharing the APK with real users, edit the Android app server URL so it points to your deployed CMMS Rails server, not `10.0.2.2`.
