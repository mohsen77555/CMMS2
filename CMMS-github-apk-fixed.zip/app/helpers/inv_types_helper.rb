module InvTypesHelper
end
