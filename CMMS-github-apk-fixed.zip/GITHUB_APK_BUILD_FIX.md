# GitHub APK build fix

For GitHub Actions to appear, these files must be at the repository root:

- `.github/workflows/build-android-apk.yml`
- `android/build.gradle`
- `android/app/build.gradle`

Do not upload a parent folder such as `CMMS-master/` into the repository root. If your GitHub repo shows `CMMS-master/.github/workflows/...`, move the files up one level.

After pushing:

1. Open **Actions**.
2. Select **Build Android APK**.
3. Click **Run workflow**.
4. Open the completed run.
5. Download the artifact named **CMMS-debug-apk**.
6. Inside it, open `app-debug.apk`.
