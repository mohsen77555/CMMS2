# CMMS Android app

This folder adds a native Android WebView shell for the existing Ruby on Rails CMMS application.

The Android app does not replace the Rails server. It connects to the running CMMS web app and displays it inside a native Android container with:

- a configurable CMMS server URL
- JavaScript, cookies, and DOM storage enabled for Rails/Devise sessions
- upload support for HTML file fields
- back-button navigation
- a friendly connection error screen

## Run the Rails app for Android development

From the project root:

```bash
bundle install
# Configure config/database.yml first, then initialize your DB:
rake db:migrate
ruby db/seeds.rb

# Important: bind to 0.0.0.0 so Android can reach the server
rails s -b 0.0.0.0 -p 3000
```

## Open the Android app

1. Open the `android/` folder in Android Studio.
2. Let Android Studio sync Gradle.
3. Run the `app` configuration on an emulator or device.

Default server URL:

```text
http://10.0.2.2:3000/
```

Use that default for the Android emulator. Android maps `10.0.2.2` to your computer's localhost.

For a physical phone, tap **Server** in the app and change the URL to your computer or server IP, for example:

```text
http://192.168.1.50:3000/
```

Your phone must be on the same network and your firewall must allow port `3000`.

## Production notes

For production, deploy the Rails app to a real HTTPS domain and change the Android server URL to that domain. You should also update `app/src/main/res/xml/network_security_config.xml` and the manifest to disable cleartext HTTP traffic once HTTPS is available.
