# Alhadi CMMS Offline Android

هذه نسخة Android داخلية تعمل بدون إنترنت وبدون Rails server.

## ماذا يعني Offline؟
- التطبيق يفتح من ملفات داخل APK: `file:///android_asset/www/index.html`.
- لا توجد صلاحية INTERNET داخل `AndroidManifest.xml`.
- البيانات تحفظ داخل الجهاز باستخدام Android SharedPreferences من خلال WebView bridge.
- لا توجد مزامنة بين عدة أجهزة إلا بالتصدير/الاستيراد JSON.

## بناء APK من GitHub
1. ارفع المشروع إلى GitHub.
2. افتح Actions.
3. شغل workflow: `Build Offline Internal APK`.
4. نزل artifact: `Alhadi-CMMS-Offline-debug-apk`.
5. فك الضغط وستجد `Alhadi-CMMS-Offline.apk`.

## رمز الدخول الافتراضي
`1234`

غيّره من الإعدادات بعد أول تشغيل.
